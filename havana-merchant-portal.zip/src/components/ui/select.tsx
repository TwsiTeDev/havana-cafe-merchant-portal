
'use client';
import React from 'react';
export function Select({value, onValueChange, defaultValue, children}: any){ return <div data-value={value} data-default={defaultValue}>{children}</div> }
export function SelectTrigger({className='', children}: any){ return <div className={`h-10 px-3 rounded-xl border flex items-center justify-between ${className}`}>{children}</div> }
export function SelectValue({placeholder}: any){ return <span className="text-slate-500">{placeholder || ''}</span> }
export function SelectContent({children}: any){ return <div className="hidden">{children}</div> } // non-interactive placeholder
export function SelectItem({value, children}: any){ return <option value={value}>{children}</option> } // for API compatibility only
