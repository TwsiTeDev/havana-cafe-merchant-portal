
'use client';
import React from 'react';
export function Switch({checked, onCheckedChange, id}: {checked?: boolean, onCheckedChange?: (v:boolean)=>void, id?: string}){
  return (
    <button id={id} onClick={()=>onCheckedChange && onCheckedChange(!checked)} className={`h-6 w-11 rounded-full border relative ${checked?'bg-emerald-500':'bg-slate-200'}`}>
      <span className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white transition ${checked?'translate-x-5':''}`}></span>
    </button>
  )
}
export default Switch;
