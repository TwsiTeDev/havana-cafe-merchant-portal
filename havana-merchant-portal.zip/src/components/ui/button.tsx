
'use client';
import React from 'react';

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'default'|'outline'|'secondary'|'destructive', size?: 'sm'|'md'|'icon' };
export const Button = React.forwardRef<HTMLButtonElement, Props>(function Button({ className='', variant='default', size='md', ...props }, ref) {
  const base = 'inline-flex items-center justify-center rounded-2xl font-medium transition border';
  const variants: Record<string,string> = {
    default: 'bg-slate-900 text-white border-slate-900 hover:opacity-90',
    outline: 'bg-white text-slate-900 border-slate-200 hover:bg-slate-50',
    secondary: 'bg-slate-100 text-slate-900 border-slate-200 hover:bg-slate-200',
    destructive: 'bg-rose-600 text-white border-rose-600 hover:bg-rose-700'
  };
  const sizes: Record<string,string> = {
    sm: 'h-8 px-3 text-sm gap-1',
    md: 'h-10 px-4 gap-2',
    icon: 'h-9 w-9 p-0'
  };
  return <button ref={ref} className={`${base} ${variants[variant]} ${sizes[size]} ${className}`} {...props} />;
});
export default Button;
