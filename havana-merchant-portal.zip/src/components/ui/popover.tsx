
'use client';
import React from 'react';
export function Popover({children}: any){ return <div>{children}</div> }
export function PopoverTrigger({asChild, children}: any){ return asChild? children : <button>{children}</button> }
export function PopoverContent({className='', children}: any){ return <div className={`p-3 rounded-2xl border bg-white ${className}`}>{children}</div> }
