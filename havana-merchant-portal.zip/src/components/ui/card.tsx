
import React from 'react';
export function Card({className='', ...props}: any){ return <div className={`rounded-2xl border bg-white ${className}`} {...props} /> }
export function CardHeader({className='', ...props}: any){ return <div className={`px-4 md:px-5 pt-4 ${className}`} {...props} /> }
export function CardTitle({className='', ...props}: any){ return <div className={`text-xl font-semibold ${className}`} {...props} /> }
export function CardContent({className='', ...props}: any){ return <div className={`px-4 md:px-5 pb-4 ${className}`} {...props} /> }
