
'use client';
import React from 'react';
export function Dialog({open, onOpenChange, children}: any){
  return open ? <div className="fixed inset-0 z-50">{children}</div> : null;
}
export function DialogContent({className='', children}: any){
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center">
      <div className={`bg-white rounded-2xl p-4 w-[90vw] max-w-2xl ${className}`}>{children}</div>
    </div>
  );
}
export function DialogHeader({children}: any){ return <div className="mb-2">{children}</div> }
export function DialogTitle({children}: any){ return <div className="text-lg font-semibold">{children}</div> }
export function DialogDescription({children}: any){ return <div className="text-sm text-slate-500">{children}</div> }
export function DialogFooter({children}: any){ return <div className="mt-3 flex justify-end gap-2">{children}</div> }
