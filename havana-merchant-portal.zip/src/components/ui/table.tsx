
import React from 'react';
export function Table({className='', ...props}: any){ return <table className={`w-full text-sm ${className}`} {...props} /> }
export function TableHeader({className='', ...props}: any){ return <thead className={className} {...props} /> }
export function TableBody({className='', ...props}: any){ return <tbody className={className} {...props} /> }
export function TableRow({className='', ...props}: any){ return <tr className={`border-b last:border-0 ${className}`} {...props} /> }
export function TableHead({className='', ...props}: any){ return <th className={`text-left py-2 px-2 text-xs text-slate-500 ${className}`} {...props} /> }
export function TableCell({className='', ...props}: any){ return <td className={`py-2 px-2 ${className}`} {...props} /> }
