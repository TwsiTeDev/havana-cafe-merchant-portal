
'use client';
import React from 'react';
export function Tabs({children}: any){ return <div>{children}</div> }
export function TabsList({className='', ...props}: any){ return <div className={`flex gap-2 ${className}`} {...props} /> }
export function TabsTrigger({value, className='', ...props}: any){ return <button className={`px-3 h-9 rounded-xl border ${className}`} {...props} /> }
export function TabsContent({value, className='', ...props}: any){ return <div className={className} {...props} /> }
