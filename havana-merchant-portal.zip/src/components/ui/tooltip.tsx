
'use client';
import React from 'react';
export function TooltipProvider({children}: any){ return children }
export function Tooltip({children}: any){ return children }
export function TooltipTrigger({asChild, children}: any){ return asChild? children : <span>{children}</span> }
export function TooltipContent({children}: any){ return null } // simplified no-op
