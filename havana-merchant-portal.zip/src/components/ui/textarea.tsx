
import React from 'react';
export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>){ return <textarea className="min-h-[100px] p-3 rounded-xl border w-full" {...props} /> }
export default Textarea;
