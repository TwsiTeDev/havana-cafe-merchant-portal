
import React from 'react';
export function Label({className='', ...props}: any){ return <label className={`text-sm text-slate-700 ${className}`} {...props} /> }
export default Label;
