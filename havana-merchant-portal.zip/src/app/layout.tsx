import "./globals.css";

export const metadata = {
  title: "Havana Cafe – Merchant Portal",
  description: "Mock merchant portal for carhop & WhatsApp orders",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gradient-to-br from-slate-50 to-white text-slate-900">
        {children}
      </body>
    </html>
  );
}
