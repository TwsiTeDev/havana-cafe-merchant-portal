import HavanaCafeMerchantPortal from "@/components/HavanaCafeMerchantPortal";

export default function Page() {
  return <HavanaCafeMerchantPortal />;
}
